#ifndef BOOKTITLEENTDELIMITERFILEHANDLER_H_
#define BOOKTITLEDELIMITERFILEHANDLER_H_
#include <stdio.h >
#include <string.h >
#include <stdlib.h >
#include " book.h "
#define DELIMITERCHAR '|'
#define ENDCHAR "-1"
#define TOTALFIELDS 3
void writeDelimitedBookDataInFile ( book_t , FILE*);
student_t readDelimitedBookDataInFile (FILE*);
#endif //BOOKTITLEDELIMITERFILEHANDLER_H_