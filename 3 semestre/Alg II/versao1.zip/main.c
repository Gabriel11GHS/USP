#include "book.h"

int n; // número de entradas
int m; // número de registros que devem sair

int main(){
    
    createStudentFile();
    readStudentFile();

}

book_t readBookDataFromInput()
{
    book_t book;
    printf("número de entradas: ");
    scanf("%d", &n);
    printf("nome do livro: ");
    scanf("%s", book.title);
    printf("nome do autor: ");
    scanf("%s", book.author);
    printf("\n");
    return student;
}

void printBookData(book_t book)
{
    printf("Id: %d\n", book.title);//printa o titulo
    printf("Título: %s\n\n", book.title);//printa o titulo
    printf("Autor: %s\n\n", book.author);//printa o autor
}