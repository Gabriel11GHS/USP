#include " BookTitleDelimiterFileHandler.h "

static char readCurrentInput (FILE * filePointer , char * currentInput )
{
    char currentChar ;
    int currentInputIndex ;
    currentInputIndex = 0;
    currentChar = fgetc ( filePointer );
    
    while (( currentChar != EOF) && ( currentChar != DELIMITERCHAR)){
        currentInput [ currentInputIndex ++] = currentChar ;
        currentChar = fgetc ( filePointer );
    }
    currentInput [ currentInputIndex ] = ' \ 0' ;
    return currentChar ;
}

void writeDelimitedBookDataInFile ( book_t book , FILE * filePointer )
{
    fprintf ( filePointer , "%d" , book.id);
    fprintf ( filePointer , "%s" , book.title);
    fputc (DELIMITERCHAR, filePointer );
    int fieldSize ;
    fieldSize = sizeof ( book.author );//mede o tamanho do campo
    fprintf ( filePointer , "%d" , fieldSize );
    fwrite (& book.author , fieldSize , 1, filePointer );
    fputc (ENDCHAR, filePointer );
}

//terminar:
book_t readDelimitedBookDataInFile (FILE * filePointer )
{
    book_t book ;
    fscanf ( filePointer , "%d" , &book.id );
    char currentInput [ 100];
    readCurrentInput ( filePointer , currentInput );
    strcpy (book.title, currentInput );
    int fieldSize ;
    fscanf ( filePointer , "%d" , &fieldSize );//lê o tamanho do campo e armazena em 'fieldsize'
    fread (& book.author , fieldSize , 1, filePointer );
    book.author[ fieldSize ] = ' \ 0' ;
    return book ;
}

/*book_t readBookDataInFile(FILE *filePointer)
{
    book_t book;
    int nFields = 0;
    char currentInput[50], currentTag[50];
    do {
        readCurrentInput(filePointer, currentTag, TAGDELIMITERCHAR);
        readCurrentInput(filePointer, currentInput, DELIMITERCHAR);
        if(strcmp(currentTag, book.) == 0)
            strcpy(book.title, currentInput);
        else if(strcmp(currentTag, AGETAG) == 0)
            strcpy(book.author, currentInput);
        else if(strcmp(currentTag, GRADETAG) == 0)
            book.grade = atoi(currentInput);
        nFields++;
    }while(nFields < TOTALFIELDS);
    return book;
}*/