#ifndef BOOK_H_
#define BOOK_H_
#include <stdio.h>
typedef struct book_t {
    int id;
    char title[100];
    char author[100];
} book_t;
book_t readBookDataFromInput();
void printBookData(book_t);
#endif //BOOK_H_